//
//  ChangeBackgroundRectIntent.swift
//  Wallpaper-WidgetExtension
//
//  Created by MAC on 24/11/2023.
//


import SwiftUI
import WidgetKit
import AppIntents
import AVFoundation
